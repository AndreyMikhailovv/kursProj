﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace examProgram
{
    public partial class captcha : Form
    {
        Random rnd = new Random();

        public captcha()
        {
            InitializeComponent();

            createCaptcha();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (captchaTB.Text == captchaLabel.Text)
            {
                Form mainnForm = new Form1();
                mainnForm.ShowDialog();
                this.Close();
            }
            else createCaptcha();
        }

        private void resetBut_Click(object sender, EventArgs e)
        {
            createCaptcha();
        }

        private void createCaptcha()
        {
            captchaLabel.Text = "";
            string arrayForCaptcha = "1234567890qwertyuiopasdfghjklzxcvbnm";
            for (int i = 0; i < 6; ++i) 
            {
                captchaLabel.Text += arrayForCaptcha[rnd.Next(arrayForCaptcha.Length)];
            }

        }
    }
}
