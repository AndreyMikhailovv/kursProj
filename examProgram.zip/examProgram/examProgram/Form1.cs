﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace examProgram
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (schetLabel.Text == "1")
            {
                MessageBox.Show("Пароль неверный", "Ошибка");
                schetLabel.Text = Convert.ToString(Convert.ToInt32(schetLabel.Text) + 1);
            }
            else if (schetLabel.Text == "2")
            {
                schetLabel.Text = "0";
                Form captchForm = new captcha();
                captchForm.ShowDialog();
                this.Hide();
            }
            else schetLabel.Text = Convert.ToString(Convert.ToInt32(schetLabel.Text) + 1);
        }
    }
}
